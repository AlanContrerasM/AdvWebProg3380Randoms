import React, { useEffect,useState } from 'react';
import { Link } from 'react-router-dom';
import Rating from '../components/Rating';
//import data from '../data';
import { useParams } from 'react-router';
import axios from "axios";

export default function ProductScreen() {
    const { id } = useParams();
    const [products, setProducts] = useState([]);
    console.log(id);

    useEffect(() => {
      fetch("http://localhost:5000/api/ProductsInfo")
        .then((res) => res.json())
        .then((res) => {
          /* console.log(res); */
          setProducts(res);
          // console.log(products);
        })
        .catch(err => {
          console.log(err);
        })
  
    }, []); //is this product here correct?
    
    const productItem=products.filter((prod)=>prod._id==id);

    //console.log(productItem);
    //const productId = id;
    //console.log(products);
   // const product = products.filter(x =>x._id === productId)
    const product=productItem[0];
    console.log(product);
    //product will be whatever got selected.

    
    const [quantity, setQuantity] = useState(1);

    const handleAddToCart= async (productItem) => {
      console.log(productItem,productItem._id);
          var newProductItem={};
          newProductItem.user="xyz";
          newProductItem.name=productItem.name;
          newProductItem.category=productItem.category;
          newProductItem.image=productItem.image;
          newProductItem.price=productItem.price;
          newProductItem.count=quantity;
          newProductItem.brand=productItem.brand;
          newProductItem.description=productItem.description;
          newProductItem.countInStock=productItem.countInStock;

          //product.count = product.countInStock;
          console.log(product);
          const { data } = await axios.post("http://localhost:5000/api/cart/" , newProductItem);
          console.log(data);
          console.log("add Handled");
          productItem.countInStock=productItem.countInStock-quantity;
          const { data1 } = await axios.put("http://localhost:5000/api/product/"+productItem._id , productItem.countInStock);
          alert("Item added to cart Successfully!");
        
      }
    
  if (!product) {
    return <div> Product Not Found</div>;
  }
  return (
    <div>
      <Link to="/">Back to Home</Link>
      
      {<div className="row top">
        <div className="col-2">
          <img className="large" src={product.image} alt={product.name}></img>
        </div>
        <div className="col-1">
          <ul>
            <li><h1>{product.name}</h1></li>
            <li>
              <Rating
                rating={product.rating}
                numReviews={product.numReviews}
              ></Rating>
            </li>
            <li>Pirce : ${product.price}</li>
            <li>Description: <p>{product.description}</p></li>
          </ul>
        </div>
        <div className="col-1">
          <div className="card card-body">
            <ul>
              <li>
                <div className="row">
                  <div>Price</div>
                  <div className="price">${product.price}</div>
                </div>
              </li>
              <li>
                <div className="row">
                  <div>Status</div>
                  <div>
                    {product.countInStock > 0 ? (
                      <span className="success">In Stock</span>
                    ) : (
                      <span className="error">Unavailable</span>
                    )}
                  </div>
                </div>
              </li>
              {product.countInStock > 0 && (
                    <>
                      <li>
                        <div className="row">
                          <div>Quantity</div>
                          <div>
                            <select
                              value={quantity}
                              onChange={(e) => setQuantity(e.target.value)}>
                              {[...Array(product.countInStock).keys()].map(
                                (item) => (
                                  <option key={item + 1} value={item + 1}>{item + 1}</option>
                                )
                              )}
                            </select>
                          </div>
                        </div>
                      </li>
                      <li>
                        <button className="primary block" onClick={()=>handleAddToCart(product)}>Add to Cart</button>
                      </li>
                    </>
                  )}
            </ul>
          </div>
        </div>
      </div>}
    </div>
  );
}