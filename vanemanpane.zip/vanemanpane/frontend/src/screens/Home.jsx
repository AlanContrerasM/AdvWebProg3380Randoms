//import React, { useEffect, useState } from 'react';
//import axios from 'axios';
import { Link } from 'react-router-dom';
import Product from '../components/Product';


export default function HomeScreen({products}) {
    // const [products, setProducts] = useState([]);
    
    // useEffect(() => { //render only one time
    //   const fecthData = async () => {
    //     try {
       
    //        const { data } = await axios.get('/api/products');
    //        setProducts(data);

    //     } catch (err) {
    //         console.log(err);
    //     }
    //     };
    //     fecthData();
    // }, []);
      return (
        <div>
             <div className="row center">
                 {products.map((product) => (
                  <Link to={`/product/${product._id}`}><Product key={product._id} product={product} ></Product></Link>
              ))}
                
            </div>
         
        </div>
      );
    }