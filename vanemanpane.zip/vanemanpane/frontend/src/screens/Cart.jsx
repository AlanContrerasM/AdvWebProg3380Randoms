import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { Link } from 'react-router-dom';


export default function CartScreen(props) {
  //console.log(props)

  const { onItemAdd, onItemSubtract, onDelete } = props;
  const [cart, setCart] = useState([]);
  var total = 0;
  //console.log(carts);


  useEffect(() => {
    fetch("http://localhost:5000/api/cart")
      .then((res) => res.json())
      .then((res) => {
        setCart(res);
        //console.log(cart);

      })
      .catch(err => {
        console.log(err);
      })

  }, [cart]); //is this product here correct?

  const cartItens = cart.filter(cart => cart.count > 0);
  return (
    <div>
      <h1>Cart Screen</h1>
      <Link to="/">Back to Home</Link>
      {
        cartItens.map((product) => (
          <div key={product._id} className="card container">

            <img className="medium" src={product.image} alt={product.name} />
            <div className="card-body">
              <h2>{product.name}</h2>
              <p>{product.description}</p>
              <div class="input-group plus-minus-input quantity">
                <div class="input-group-button">
                  <button type="button" class="button hollow circle" data-quantity="minus" data-field="quantity" onClick={() => onItemSubtract(product).then(x => alert(x.message))}>
                    <i class="fa fa-minus" aria-hidden="true"></i>
                  </button>
                  <button className="btn btn-primary" onClick={() => onDelete(product).then(x =>{ alert(x.message); })}>Remove</button>
                </div>
                <input class="input-group-field" type="text" name="quantity" readOnly value={product.count} />
                <div class="input-group-button">
                  <button type="button" class="button hollow circle" data-quantity="plus" data-field="quantity" onClick={() => onItemAdd(product).then(x => alert(x.message))}>
                    <i class="fa fa-plus" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <div className="price">${product.price} per each item  i.e Total = ${ product.price * product.count}</div>
              <div hidden>{total +=product.price * product.count}</div>
            </div>

          </div>

        ))
      }
      <div class="button-wrapper" data-tippy-content="Click to copy button 63">
        <button class="button-63" role="button">Procced to Checkout ${total}</button>
      </div>
    </div>
  );
}