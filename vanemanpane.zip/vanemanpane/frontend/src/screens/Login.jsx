import React from 'react'
import { Link } from 'react-router-dom';

const Login = () => {
    return (
        <div>
           

               
                    <div class="contentLog">
                        <h1>Login</h1>
                        <div class="form-group">
                            <label for="">Email</label>
                            
                            <input type="email" class="form" name="" id="" aria-describedby="helpId" placeholder=""/>
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                        
                            <input type="password" class="form" name="" id="" placeholder=""/>
                        </div>
                    
                      
                        <button className="log" type="button"><Link to="/">Login</Link></button> 
                         </div>
            
        </div>
    )
}

export default Login;
