import React, { useEffect, useState } from "react";
import { Route, Routes, BrowserRouter, Link } from 'react-router-dom';
import NewProductForm from "./screens/NewProductForm.jsx";
import Cart from "./screens/Cart";
import Home from "./screens/Home";
import ProductScreen from "./screens/ProductScreen.jsx";
import Login from "./screens/Login.jsx";
import axios from "axios";
import product from "./components/Product.js";


function App() {

  const [products, setProducts] = useState(null);
  const [productToShow, setProductToShow] = useState([]);
  const [newProduct, setNewProduct] = useState({});
  //const [cart, setCart] = useState([]);

  const fetchData = async ()=>{
    try{
      const products = await axios.get("http://localhost:5000/api/ProductsInfo")
      console.log(products.data); 
      setProducts(products.data);

    }catch(err){
      console.log(err);
    }
  }


  useEffect(() => {
    fetchData();

  }, []); //is this product here correct?



  /*useEffect(() => {
    fetch("http://localhost:5000/api/cart")
      .then((res) => res.json())
      .then((res) => {
        setCart(res);
        //console.log(cart);
        
      })
      .catch(err => {
        console.log(err);
      })

  }, [cart]); //is this product here correct?*/

  
  

  const handleItemAdd = async (product) => { //post request adds something to the database.
    /*   console.log(newProduct); */
    if (product.count < product.countInStock) {
      product.count = product.count + 1;
      //product.count = product.countInStock;
      console.log(product);
      const { data } = await axios.put("http://localhost:5000/api/cart/" + product._id, product);
      console.log(data);
      console.log("add Handled");
      const index = products.indexOf(product);
      products[index] = { ...product };
      //console.log(products);
      setProducts([...products]);
      return { "message": "Item updated Successfully!" };
    }
    else
      return { "message": "Reached max quantity!" };

  }

  const handleItemSubtract = async (product) => { //post request adds something to the database.
    /*   console.log(newProduct); */
    if (product.count > 0) {
      product.count = product.count > 0 ? product.count - 1 : 0;
      const { data } = await axios.put("http://localhost:5000/api/cart/" + product._id, product);
      console.log("subtract Handled");
      const index = products.indexOf(product);
      products[index] = { ...product };
      //console.log(products);
      setProducts([...products]);
      return { "message": "Item updated Successfully!" };
    }
    else
      return { "message": "Removed item!"};

  }


  const handleItemDelete = async (product) => {
    console.log("Delete handled");
    const { data } = await axios.delete("http://localhost:5000/api/cart/" + product._id);
    const newProducts = products.filter(s => s._id != product._id);

    //console.log(data, newProducts);
    setProducts([...newProducts]);
    /*return { "message": "Item removed Successfully!",
             "products": newProducts };*/
    return { "message": "Item removed Successfully!"};
  }


  if(products){

    return (
      <BrowserRouter>
      <div className="grid-container">
        <header className="row">
          <div>
            <a className="brand" href="/">GiftShop</a>
          </div>
          <div>
            <Link to="/cart">Cart</Link>
            <Link to="/newProduct">+ New Product</Link>
            <Link to="/login">Log In</Link>
          </div>
        </header>
        <main>
          <Routes>
            <Route path="/newProduct" element={<NewProductForm />} />
            <Route path="/cart" element={<Cart
              onItemAdd={handleItemAdd}
              onItemSubtract={handleItemSubtract}
              onDelete={handleItemDelete} />} />
            <Route path="/login" element={<Login />} />
            <Route path="/product/:id" element={<ProductScreen />}  />
            <Route path="/" exact element={<Home products={products} productToShow={productToShow} />} />
          </Routes>
        </main>
        <footer className="row center">2021 All right reserved</footer>
      </div>
    </BrowserRouter>
    );
  }else{
    return "loading";
  }
}

export default App;
