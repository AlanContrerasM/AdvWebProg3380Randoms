import React from 'react'

const Notfound = () => {
    return (
        <div>
            <h1>Resources is not found</h1>
        </div>
    )
}

export default Notfound
